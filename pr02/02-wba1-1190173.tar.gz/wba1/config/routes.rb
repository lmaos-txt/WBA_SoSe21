Rails.application.routes.draw do
  get 'pr02/einleitung'
  get 'pr02/kap1'
  get 'pr02/kap2'
  get 'pr02/tab'
  get 'pr01/einleitung'
  get 'pr01/index'
  get 'pr01/kap1'
  get 'pr01/kap2'
  get 'pr01/tab'
  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
