require "test_helper"

class Pr01ControllerTest < ActionDispatch::IntegrationTest
  test "should get einleitung" do
    get pr01_einleitung_url
    assert_response :success
  end

  test "should get index" do
    get pr01_index_url
    assert_response :success
  end

  test "should get kap1" do
    get pr01_kap1_url
    assert_response :success
  end

  test "should get kap2" do
    get pr01_kap2_url
    assert_response :success
  end

  test "should get tab" do
    get pr01_tab_url
    assert_response :success
  end
end
