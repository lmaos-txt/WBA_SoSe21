var bntList = [];
var display;
var radConversion = (Math.PI/180);
var degConversion = (180/Math.PI);
Check = function(Eingabe) { 
    var nur_das = "0123456789[]()-+*%/."; 
        for (var i = 0; i < Eingabe.length; i++) 
        if (nur_das.indexOf(Eingabe.charAt(i)) < 0) 
            return false; 
            return true; 
}
 
Ergebnis = function() { 
    var x = 0; 
    if (Check($(display).val())){
        $(display).val(eval($(display).val()));
    }
} 
 
Hinzufuegen = function(Zeichen) { 
    $(display).val($(display).val() + Zeichen);
} 
 
Sonderfunktion = function (Funktion) { 
    if(Check($(display).val())){
        switch (Funktion) {
            case "√x":
                $(display).val(Math.sqrt(eval($(display).val()))); 
                break;
            case "x²":
                $(display).val(eval($(display).val()) * eval($(display).val()));
                break;
            case "ln":
                $(display).val(Math.log(eval($(display).val())));
                break;
            case "exp":
                $(display).val(Math.exp(eval($(display).val())));
                break;
            case "lg":
                $(display).val(Math.log10(eval($(display).val())));
                break;
            case "10^x":
                $(display).val(Math.pow(10,eval($(display).val())));
                break;
            case "sin":
            case "cos":
            case "tan":
                $(display).val(window["Math"][Funktion](eval($(display).val())*radConversion));
                break;
            case "cot":
                $(display).val(1/Math.tan(eval($(display).val())*radConversion));
                break;
            case "asin":
            case "acos":
            case "atan":
                $(display).val(window["Math"][Funktion](eval($(display).val()))*degConversion);
                break;
            default:
                $(display).val(0);
                break;
        }
    }else $(display).val(0)
    
} 
Umschalten = function (val){
    $('input[type="button"]').off("click");
    let btns = ["ln", "exp", "lg", "10^x","sin", "cos", "tan", "cot","asin", "acos", "atan", "Deg"];
    switch ($(val).attr("value")) {
        case "Std":
            $(val).attr("value","Sci");//Switch to SCI Mode
            let sciBox = $("<div class = \"SciWrapper\"/>");
            $(sciBox).hide();
            $('#fields').append(sciBox);
            btns.forEach(element => {
                AddButton(element,true);
            });
            $(sciBox).fadeIn(500);
            break;
        case "Sci":
            $(val).attr("value","Std");//Switch to STD Mode
            btns.forEach(element => {
                RemoveButton(element,true);
            });

            break;
        case "Deg":
            $(val).attr("value","Rad");//Switch to Rad Mode
            radConversion = 1;
            degConversion = 1;
            $(display).val(eval($(display).val()*degConversion));
            break;   
        case "Rad":
            $(val).attr("value","Deg");//Switch to Deg Mode
            radConversion = (Math.Pi/180);
            degConversion = (180/Math.PI);
            $(display).val(eval($(display).val()*radConversion));
            break;      
        default:
            break;
    }
    bindButtonEvent();
}


jQuery(function() { // $(document).ready is deprecated
    let btns = [7,8,9,"+",4,5,6,"-",1,2,3,"*",0,".","=","/","√x", "x²", "Std" , "C"]
    for (let i = 0; i < btns.length; i++) {
        AddButton(btns[i])
    }
    bntList.push(btns);
    display = $("#Display");
    $(display).val("");

    bindButtonEvent();
})

bindButtonEvent = function(){
    $('input[type="button"]').on ("click",function(event) {
        switch($(this).attr('data-cmd')) {
        case 'result': Ergebnis(); break;
        case 'function': Sonderfunktion(this.value); break;
        case 'switch': Umschalten(this); break;
        case 'clear': Sonderfunktion(this.value); break;
        default: Hinzufuegen(this.value);
        }
    });
}
AddButton = function(value,anim) {
    let button;
    switch (value) {
        case "√x":
        case "x²":
            button = $("<input type ='button' value=\""+value+"\" data-cmd=\"function\" name='"+value+"'>");
            break;
        case "C":
            button = $("<input type ='reset' value=\""+value+"\" data-cmd=\"clear\" name='"+value+"'>");
            break;
        case "=":
            button = $("<input type ='button' value=\""+value+"\" data-cmd=\"result\" name='"+value+"'>");
            break;
        case "Std":
        case "Deg":
                button = $("<input type ='button' value=\""+value+"\" data-cmd=\"switch\" name='"+value+"' class='toggle'>");
            break;
        case "ln":
        case "exp":
        case "lg":
        case "10^x":
        case "sin":
        case "tan":
        case "cot":
        case "asin":
        case "acos":
        case "atan":
        case "cos":
        case "Deg":
            button = $("<input type ='button' value=\""+value+"\" data-cmd=\"function\" name='"+value+"' class='Sci'>");
            break;
        default:
            button = $("<input type ='button' value=\""+value+"\" data-cmd=\"add\" name='"+value+"'>");
            break;
    }
    if(anim){
        $(".SciWrapper").append(button);
    } else $('#fields').append(button);
}
RemoveButton = function(btn,sci){
    if(sci){
        $(".SciWrapper").fadeOut(500).promise().then(function(){
            $(".SciWrapper").remove();
        });
        return;
    }
    bt = $("input[value='"+btn+"']");
    $(bt).hide(500);
    setTimeout(() => {
        $(bt).remove();
    }, 600);
    bntList = bntList.filter(function(val,index,arr){
        return val != btn;
    })
}
