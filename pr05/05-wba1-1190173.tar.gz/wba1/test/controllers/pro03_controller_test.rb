require "test_helper"

class Pro03ControllerTest < ActionDispatch::IntegrationTest
  test "should get anmeldung" do
    get pro03_anmeldung_url
    assert_response :success
  end

  test "should get fragebogen" do
    get pro03_fragebogen_url
    assert_response :success
  end
end
