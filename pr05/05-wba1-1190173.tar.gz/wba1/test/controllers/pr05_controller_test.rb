require "test_helper"

class Pr05ControllerTest < ActionDispatch::IntegrationTest
  test "should get tr" do
    get pr05_tr_url
    assert_response :success
  end
end
