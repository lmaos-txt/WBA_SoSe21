var marriedTr;
jQuery(function () {
    marriedTr = $('select#params_married_since_1i').parent().parent();
    console.log(marriedTr);
    hideMarried();
    $('input[type="radio"][name="params[marital_status]"]').on ("click",function(event) {
        switch($(this).attr('value')) {
        case 'v': showMarried(); break;
        default: hideMarried();
    }
    });
    $('form[action="anmeldung"').on("submit",function(ev){
        if($("#params_password_confirmation").val() == $('#params_password').val()){
            $(this).trigger("submit");
            return;
        }
        else{
            ev.preventDefault();
            alert("Passwörter sind nicht identisch")
        }
    });
});

hideMarried = function(){
    $(marriedTr).remove();
}
showMarried = function(){
    let maritalStatus = $('input[name="params[marital_status]"]').parent().parent().parent();
    console.log(maritalStatus);
    $(maritalStatus).after(marriedTr);
}