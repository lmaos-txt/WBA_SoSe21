let unit_arr = []
jQuery(function(){
    $('#test').DataTable();
    $.getJSON("/eu-data.json")
        .done(function(data){
            console.log(data)
            $.each(data,function(key,value){
                if(key == "Spaltentitel")
                    add_row($('#pr06thead'), key, value,'<th>')
                else if(key == "Einheit")
                    add_row($('#pr06thead'), key, value,'<td>')
                else if(key == "Titel")
                    console.log(key)
                else{
                    console.log(value)
                    add_row($('#pr06tbody'),key,value, '<td>')
                }
            });
        })
});

add_row = function(parent, key, data,elem){
    console.log(data)
    tbl_row = $("<tr></tr")
    parent.append(tbl_row)
    parent = tbl_row
    if(key != "Spaltentitel" && key != "Einheit")
        parent.append(elem+""+key+""+make_closing(elem))
    $.each(data,function(key,val){
        parent.append(elem+ ""+val+""+make_closing(elem))
    })
    parent.append("</tr>")
    //parent.append(elem+ ""+data+""+make_closing(elem))
}
make_closing = function(elem){
    return elem.replace("<","</");
}
fill_unit = function(elem){

}