class Pr06Controller < ApplicationController
  def graphs
  end
end
