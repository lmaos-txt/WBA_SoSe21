
//= require rails-ujs
//= require turbolinks
//= require jquery
//= require datatables.net
//= require_tree 
//= jqChart
let unit_arr = []
let table;
jQuery(function(){
    $.getJSON("/eu-data.json")
        .done(function(data){
            $.each(data,function(key,value){
               if(key == "Spaltentitel")
                    add_row($('#pr06thead'), key, value,'<th>')
               else if(key == "Einheit")
                    add_row($('#pr06thead'), key, value,'<td>')
                else if(key == "Titel")
                    console.log()
                else{
                    add_row($('#pr06tbody'),key,value, '<td>')
                }
            });
            table = $('#pr06table').DataTable();
            $('.dataTable thead').on( 'click', 'th', function () {
                let column_index = $(this).index()
                make_graph_decider(column_index)
            });
        });

});

add_row = function(parent, key, data,elem){
    tbl_row = $("<tr></tr>")
    parent.append(tbl_row)
    parent = tbl_row
    if(key != "Spaltentitel" && key != "Einheit")
        parent.append(elem+""+key+""+make_closing(elem))
    $.each(data,function(key,val){
        parent.append(elem+ ""+val+""+make_closing(elem))
    })
}
make_closing = function(elem){
    return elem.replace("<","</");
}
draw_chart = function(column_index, chart_type){
    let countries = table.column(0).data()
    let data = table.column(column_index).data()
    let chart_data = []
    let tmp = []
    let tmp2 = []
    let header = table.column(column_index).header()
    let title = $('#pr06table th')[column_index].innerHTML+"("+header.innerHTML+")"


    for (let i = 0; i < data.length; i++) {
        chart_data.push([countries[i],data[i]])
        tmp.push(data[i])
        tmp2.push(countries[i])
    }
    data = tmp
    countries = tmp2

    $('#pr06chart').jqChart({
        title: { 
            text: title 
        },
        axes: [
            {
                type: 'linear',
                location: 'left',
                minimum: 0,
                maximum: Math.max(...data) + Math.max(...data) / 100,
                zoomEnabled: true
            }
        ],
        series: [
            {
                type: chart_type,
                data: chart_data
            }
        ]
    });
    $('#dia').show();
}

make_graph_decider = function(col) {    
    if(table.column(col).header().innerHTML == "-"){
        alert("Tabelle macht logisch keinen Sinn!");
        return
    }
    let elem = $('#decide')
    console.log(elem)
    elem.append("<div></div>")
    elem = $('#decide>div')
    elem.append("<div></div>")
    elem = $('#decide>div>div')
    elem.append("<h3>Wählen Sie einen Graphtypen aus!</h3>")

    elem.append("<button type=\"pie\" number=\""+col+"\">Pie</button>")
    elem.append("<button type=\"column\" number=\""+col+"\">Column</button>")
    
    elem.parent().parent().css("position","absolute")
    elem.parent().parent().css("background-color","#0000009e")
    elem.parent().parent().css("width","100vw")
    elem.parent().parent().css("height","100vh")
    elem.parent().parent().css("z-index","5")
    elem.parent().parent().css("top","0px")
    elem.parent().parent().css("overflow","hidden")

    elem.parent().css("margin","0px")

    elem.css("background-color","white")
    elem.css("border","solid 1px black")
    elem.css("position","absolute")
    elem.css("top","45vh")
    elem.css("left","40vw")
    elem.css("padding","10px")
    elem.css("border-radius","10px")

    $('#decide button[type=\'pie\']').on('click',function(){
        draw_chart($(this).attr('number'),'pie')
        elem.parent().remove()
        elem.parent().hide()
        $('#decide').removeAttr("style")
    });

    $('#decide button[type=\'column\']').on('click',function(){
        draw_chart($(this).attr('number'),'column')
        elem.parent().remove()
        elem.parent().hide()
        $('#decide').removeAttr("style")
    });

    elem.show()


}