module Pr06Helper
end
