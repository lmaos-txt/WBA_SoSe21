require "test_helper"

class Pr06ControllerTest < ActionDispatch::IntegrationTest
  test "should get graphs" do
    get pr06_graphs_url
    assert_response :success
  end
end
