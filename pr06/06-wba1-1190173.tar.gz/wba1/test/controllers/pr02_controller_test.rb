require "test_helper"

class Pr02ControllerTest < ActionDispatch::IntegrationTest
  test "should get einleitung" do
    get pr02_einleitung_url
    assert_response :success
  end

  test "should get kap1" do
    get pr02_kap1_url
    assert_response :success
  end

  test "should get kap2" do
    get pr02_kap2_url
    assert_response :success
  end

  test "should get tab" do
    get pr02_tab_url
    assert_response :success
  end
end
